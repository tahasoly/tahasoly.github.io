function For_visiable_and_unVisiable_page_loader(){

    document.style.display = "none";


}
For_visiable_and_unVisiable_page_loader();